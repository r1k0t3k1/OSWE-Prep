TYPE_JSON='application/json'
NOSQEAK='No sqeaks were found'
METHOD='Unsupported method'
MISSING_AUTH='Missing required authentication'
SPECIAL_CHARS=["/","$","~","#","%","&","`","!","(",")","{","}","[","]","|","\\","<",">","?",'"',"'"]